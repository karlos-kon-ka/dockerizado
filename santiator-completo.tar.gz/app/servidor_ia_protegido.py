#!/usr/bin/env python3
from flask import Flask, request, jsonify, render_template_string
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
import torch
import os
import sys

# Añadir sistema al path
sys.path.append('/app/sistema')

from respuesta_segura import RespuestaSegura

# Configuración
MODEL_PATH = os.getenv('MODEL_PATH', 'microsoft/DialoGPT-small')
app = Flask(__name__)

# Cargar modelo DialoGPT
print("🚀 Iniciando servidor con DialoGPT (conocimiento general)...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
model = AutoModelForCausalLM.from_pretrained(MODEL_PATH)
seguridad = RespuestaSegura()

# Crear pipeline de conversación
chat_pipeline = pipeline(
    "text-generation",
    model=model,
    tokenizer=tokenizer,
    max_length=150,
    temperature=0.7,
    top_p=0.9,
    repetition_penalty=1.2
)

def generar_respuesta_conversacional(mensaje):
    """Genera respuesta usando DialoGPT con contexto seguro"""
    
    prompt = f"""Eres Santiator, un asistente amigable y seguro para niños. Responde en español de manera apropiada.

Ejemplos de respuestas correctas:
Usuario: ¿quién es JFK?
Tú: John F. Kennedy fue el 35º presidente de Estados Unidos, conocido por su liderazgo durante la Crisis de los Misiles y por promover el programa espacial.

Usuario: cuéntame un chiste
Tú: ¿Qué le dice un semáforo a otro? ¡No me mires, me estoy cambiando! 😄

Usuario: cómo aprender matemáticas
Tú: Las matemáticas pueden ser divertidas. Empieza con juegos de sumas y practica con problemas de la vida diaria.

Ahora responde a esta pregunta:
Usuario: {mensaje}
Santiator:"""
    
    try:
        # Generar respuesta con DialoGPT
        respuesta = chat_pipeline(
            prompt,
            max_length=len(prompt) + 100,
            num_return_sequences=1,
            pad_token_id=tokenizer.eos_token_id
        )[0]['generated_text']
        
        # Extraer solo la parte del asistente
        if "Santiator:" in respuesta:
            respuesta_final = respuesta.split("Santiator:")[-1].strip()
        else:
            respuesta_final = respuesta.replace(prompt, "").strip()
            
        return respuesta_final
        
    except Exception as e:
        return f"¡Hola! Soy Santiator. Me encanta aprender cosas nuevas contigo. ¿Podrías contarme más sobre lo que te interesa?"

def verificar_respuesta_final(respuesta, mensaje_original):
    """Verifica que la respuesta sea segura"""
    palabras_peligrosas = ["cómo", "paso a paso", "instrucciones", "debes", "tienes que"]
    
    mensaje_lower = mensaje_original.lower()
    respuesta_lower = respuesta.lower()
    
    # Si es pregunta peligrosa y la respuesta da instrucciones
    if any(palabra in mensaje_lower for palabra in ['daño', 'violar', 'matar', 'lastimar', 'escapar']) and \
       any(palabra in respuesta_lower for palabra in palabras_peligrosas):
        return "No puedo proporcionar esa información. Si necesitas ayuda, habla con un adulto de confianza."
    
    # Asegurar que responda en español (fallback)
    if len(respuesta.split()) < 3 or "english" in respuesta_lower or "sorry" in respuesta_lower:
        return "¡Qué interesante pregunta! Como asistente en español, me especializo en conversaciones amigables y educativas. ¿Te gustaría que hablemos de algún tema específico?"
    
    return respuesta

# EL HTML PERMANECE EXACTAMENTE IGUAL (tu frontend bestial)
HTML = '''
<!DOCTYPE html>
<html>
<head>
    <title>🤖 Santiator - Chat Seguro</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .chat-container {
            width: 100%;
            max-width: 900px;
            height: 80vh;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .chat-header {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: white;
            padding: 25px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .chat-header h1 {
            font-size: 2.2em;
            font-weight: 700;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .chat-header p {
            font-size: 1.1em;
            opacity: 0.9;
            font-weight: 300;
        }

        .chat-messages {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 15px;
            background: #f8f9fa;
        }

        .message {
            max-width: 80%;
            padding: 18px 20px;
            border-radius: 18px;
            line-height: 1.5;
            font-size: 1.05em;
            position: relative;
            animation: messageAppear 0.3s ease-out;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        @keyframes messageAppear {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .message.user {
            align-self: flex-end;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-bottom-right-radius: 6px;
        }

        .message.ia {
            align-self: flex-start;
            background: white;
            color: #333;
            border: 1px solid #e1e5e9;
            border-bottom-left-radius: 6px;
        }

        .message.seguridad {
            align-self: flex-start;
            background: linear-gradient(135deg, #ff6b6b, #ee5a52);
            color: white;
            border-bottom-left-radius: 6px;
            font-weight: 600;
        }

        .message strong {
            display: block;
            margin-bottom: 8px;
            font-size: 0.9em;
            opacity: 0.9;
        }

        .chat-input-container {
            padding: 20px;
            background: white;
            border-top: 1px solid #e1e5e9;
            display: flex;
            gap: 12px;
            align-items: center;
        }

        #mensaje {
            flex: 1;
            padding: 16px 20px;
            border: 2px solid #e1e5e9;
            border-radius: 25px;
            font-size: 1.1em;
            outline: none;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        #mensaje:focus {
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        button {
            padding: 16px 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 25px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }

        button:active {
            transform: translateY(0);
        }

        .typing-indicator {
            align-self: flex-start;
            background: white;
            padding: 15px 20px;
            border-radius: 18px;
            border: 1px solid #e1e5e9;
            color: #666;
            font-style: italic;
        }

        .typing-dots {
            display: inline-block;
        }

        .typing-dots span {
            animation: typing 1.4s infinite;
            opacity: 0.6;
        }

        .typing-dots span:nth-child(2) { animation-delay: 0.2s; }
        .typing-dots span:nth-child(3) { animation-delay: 0.4s; }

        @keyframes typing {
            0%, 60%, 100% { opacity: 0.3; }
            30% { opacity: 1; }
        }

        /* Scrollbar personalizado */
        .chat-messages::-webkit-scrollbar {
            width: 6px;
        }

        .chat-messages::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 3px;
        }

        .chat-messages::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 3px;
        }

        .chat-messages::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }

        @media (max-width: 768px) {
            .chat-container {
                height: 90vh;
                border-radius: 15px;
            }
            
            .message {
                max-width: 90%;
                font-size: 1em;
            }
            
            .chat-header h1 {
                font-size: 1.8em;
            }
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-header">
            <h1>🤖 Santiator</h1>
            <p>Tu asistente seguro y amigable</p>
        </div>
        
        <div class="chat-messages" id="chat">
            <div class="message ia">
                <strong>Santiator</strong>
                ¡Hola! Soy Santiator, ahora con más conocimiento general. Puedo ayudarte con preguntas sobre historia, ciencia, y mucho más. ¿En qué puedo asistirte hoy?
            </div>
        </div>
        
        <div class="chat-input-container">
            <input type="text" id="mensaje" placeholder="Escribe tu mensaje aquí..." autocomplete="off">
            <button onclick="enviarMensaje()">Enviar</button>
        </div>
    </div>

    <script>
        let isLoading = false;

        function enviarMensaje() {
            if (isLoading) return;
            
            let mensaje = document.getElementById('mensaje').value.trim();
            if (!mensaje) return;
            
            let chat = document.getElementById('chat');
            
            // Agregar mensaje del usuario
            chat.innerHTML += `
                <div class="message user">
                    <strong>Tú</strong>
                    ${mensaje}
                </div>
            `;
            
            // Limpiar input
            document.getElementById('mensaje').value = '';
            
            // Mostrar indicador de typing
            chat.innerHTML += `
                <div class="typing-indicator" id="typing">
                    <strong>Santiator</strong>
                    Escribiendo<span class="typing-dots"><span>.</span><span>.</span><span>.</span></span>
                </div>
            `;
            
            chat.scrollTop = chat.scrollHeight;
            isLoading = true;
            
            // Enviar mensaje al servidor
            fetch('/chat', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({mensaje: mensaje})
            })
            .then(r => r.json())
            .then(data => {
                // Remover indicador de typing
                document.getElementById('typing')?.remove();
                
                let clase = data.tipo === 'seguridad' ? 'seguridad' : 'ia';
                let emoji = data.tipo === 'seguridad' ? '🛡️' : '🤖';
                
                chat.innerHTML += `
                    <div class="message ${clase}">
                        <strong>${emoji} Santiator</strong>
                        ${data.respuesta}
                    </div>
                `;
                
                chat.scrollTop = chat.scrollHeight;
                isLoading = false;
            })
            .catch(error => {
                document.getElementById('typing')?.remove();
                chat.innerHTML += `
                    <div class="message seguridad">
                        <strong>❌ Error</strong>
                        No se pudo conectar con el servidor. Intenta nuevamente.
                    </div>
                `;
                chat.scrollTop = chat.scrollHeight;
                isLoading = false;
            });
        }
        
        // Enviar con Enter
        document.getElementById('mensaje').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') enviarMensaje();
        });
        
        // Auto-focus en el input
        document.getElementById('mensaje').focus();
    </script>
</body>
</html>
'''

@app.route('/')
def home():
    return render_template_string(HTML)

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    mensaje = data.get('mensaje', '')
    
    # PRIMERO: Verificar seguridad
    resultado_seguridad = seguridad.procesar_mensaje(mensaje)
    
    if resultado_seguridad['tipo'] == 'seguridad':
        return jsonify({
            "respuesta": resultado_seguridad['respuesta'],
            "tipo": "seguridad",
            "riesgo": resultado_seguridad['riesgo']
        })
    
    # SEGUNDO: Generar respuesta con DialoGPT
    respuesta_ia = generar_respuesta_conversacional(mensaje)
    
    # VERIFICACIÓN FINAL de seguridad
    respuesta_final = verificar_respuesta_final(respuesta_ia, mensaje)
    
    return jsonify({
        "respuesta": respuesta_final,
        "tipo": "normal",
        "riesgo": "ninguno"
    })

if __name__ == '__main__':
    print("🌐 Servidor DialoGPT listo en: http://0.0.0.0:5000")
    print("🛡️  Sistema de protección activado")
    print("🧠 Conocimiento general: ACTIVADO")
    app.run(host='0.0.0.0', port=5000, debug=False)
