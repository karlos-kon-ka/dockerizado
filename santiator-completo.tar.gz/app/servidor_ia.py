
#!/usr/bin/env python3
from flask import Flask, request, jsonify, render_template_string
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
import re
import os
import PyPDF2
import docx

# Configuración para Docker
MODEL_PATH = os.getenv('MODEL_PATH', './santiator-trained')
DOCUMENTOS_PATH = os.getenv('DOCUMENTOS_PATH', './documentos')

# Asegurar directorios existen
os.makedirs(DOCUMENTOS_PATH, exist_ok=True)
app = Flask(__name__)

# Cargar modelo una sola vez
print("🚀 Iniciando servidor IA - SOLO CHAT Y DOCUMENTOS...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
model = AutoModelForCausalLM.from_pretrained(MODEL_PATH)

# Procesador de documentos
class ProcesadorDocumentos:
    def __init__(self):
        self.documentos_dir = "documentos"
        if not os.path.exists(self.documentos_dir):
            os.makedirs(self.documentos_dir)
    
    def extraer_texto_pdf(self, archivo_path):
        """Extrae texto de PDF"""
        try:
            with open(archivo_path, 'rb') as archivo:
                lector = PyPDF2.PdfReader(archivo)
                texto = ""
                for pagina in lector.pages:
                    texto += pagina.extract_text() + "\n"
                return texto.strip()
        except Exception as e:
            return f"Error leyendo PDF: {e}"
    
    def extraer_texto_docx(self, archivo_path):
        """Extrae texto de Word"""
        try:
            doc = docx.Document(archivo_path)
            texto = ""
            for parrafo in doc.paragraphs:
                if parrafo.text.strip():
                    texto += parrafo.text + "\n"
            return texto.strip()
        except Exception as e:
            return f"Error leyendo Word: {e}"
    
    def extraer_texto_txt(self, archivo_path):
        """Extrae texto de TXT"""
        try:
            with open(archivo_path, 'r', encoding='utf-8') as archivo:
                return archivo.read().strip()
        except Exception as e:
            return f"Error leyendo TXT: {e}"
    
    def procesar_documento(self, archivo_path):
        """Procesa cualquier tipo de documento"""
        extension = archivo_path.lower().split('.')[-1]
        
        if extension == 'pdf':
            return self.extraer_texto_pdf(archivo_path)
        elif extension == 'docx':
            return self.extraer_texto_docx(archivo_path)
        elif extension == 'txt':
            return self.extraer_texto_txt(archivo_path)
        else:
            return f"Formato no soportado: {extension}"
    
    def guardar_documento(self, archivo):
        """Guarda archivo subido"""
        archivo_path = os.path.join(self.documentos_dir, archivo.filename)
        archivo.save(archivo_path)
        return archivo_path

# Inicializar procesador
procesador = ProcesadorDocumentos()

class FiltroRegex:
    def __init__(self):
        self.patrones = {
            'info_personal': r'\b\d{8,9}[A-Za-z]?\b|\b\d{16}\b',
            'contacto': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'seguridad': r'(password|contraseña|clave|secret)[\s:=]+\S+',
            'urls': r'https?://[^\s]+'
        }
    
    def filtrar_input(self, texto):
        texto = re.sub(self.patrones['info_personal'], '[INFO_PERSONAL]', texto)
        texto = re.sub(self.patrones['contacto'], '[EMAIL]', texto)
        return texto
    
    def filtrar_output(self, texto):
        texto = re.sub(self.patrones['seguridad'], r'\1 [PROTEGIDO]', texto, flags=re.IGNORECASE)
        texto = re.sub(self.patrones['urls'], '[ENLACE]', texto)
        return texto

filtro = FiltroRegex()

HTML = '''
<!DOCTYPE html>
<html>
<head>
    <title>SANTIATOR - CHAT Y DOCUMENTOS</title>
    <style>
        body { font-family: Arial; margin: 20px; background: #f0f0f0; }
        .chat-container { max-width: 900px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
        .message { margin: 10px 0; padding: 10px; border-radius: 5px; }
        .user { background: #007bff; color: white; text-align: right; }
        .ia { background: #28a745; color: white; }
        input, button { padding: 10px; margin: 5px; }
        .seccion { margin-top: 30px; border-top: 2px solid #ccc; padding-top: 20px; }
        .loading { color: #ff9800; }
        .error { color: #dc3545; }
        .success { color: #28a745; }
        .ejemplos { background: #e7f3ff; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .ejemplo-btn { background: #6c757d; color: white; border: none; padding: 5px 10px; margin: 2px; border-radius: 3px; cursor: pointer; }
        .documento-info { background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>
    <div class="chat-container">
        <h1>🤖 SANTIATOR - CHAT Y DOCUMENTOS</h1>
        
        <!-- Chat de Texto -->
        <div>
            <h2>💬 Chat Inteligente</h2>
            <div id="chat"></div>
            <input type="text" id="mensaje" placeholder="Pregunta lo que quieras..." style="width: 70%">
            <button onclick="enviarMensaje()">Enviar</button>
        </div>

        <!-- Análisis de Documentos -->
        <div class="seccion">
            <h2>📄 Análisis de Documentos</h2>
            
            <div class="ejemplos">
                <strong>Formatos soportados: PDF, Word (.docx), TXT</strong>
            </div>
            
            <!-- Subir documento -->
            <div>
                <h3>📤 Subir Documento</h3>
                <input type="file" id="archivo-documento" accept=".pdf,.docx,.txt">
                <button onclick="subirDocumento()">Subir y Procesar</button>
                <div id="resultado-subida"></div>
            </div>
            
            <!-- Analizar documento -->
            <div style="margin-top: 20px;">
                <h3>❓ Preguntar sobre Documento</h3>
                <input type="text" id="pregunta-documento" placeholder="¿Qué quieres saber del documento?" style="width: 60%">
                <input type="text" id="nombre-archivo" placeholder="Nombre del archivo" style="width: 30%">
                <button onclick="analizarDocumento()">Analizar Documento</button>
                <div id="resultado-analisis"></div>
            </div>
        </div>
    </div>

    <script>
        // Chat de texto
        function enviarMensaje() {
            let mensaje = document.getElementById('mensaje').value;
            if (!mensaje) return;
            
            let chat = document.getElementById('chat');
            let userMsg = `<div class="message user"><strong>Tú:</strong> ${mensaje}</div>`;
            chat.innerHTML += userMsg;
            document.getElementById('mensaje').value = '';
            
            fetch('/chat', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({mensaje: mensaje})
            })
            .then(r => r.json())
            .then(data => {
                chat.innerHTML += `<div class="message ia"><strong>IA:</strong> ${data.respuesta}</div>`;
                chat.scrollTop = chat.scrollHeight;
            })
            .catch(error => {
                chat.innerHTML += `<div class="message error"><strong>Error:</strong> No se pudo conectar</div>`;
            });
        }

        // Subir documento
        function subirDocumento() {
            let archivoInput = document.getElementById('archivo-documento');
            let archivo = archivoInput.files[0];
            
            if (!archivo) {
                alert('Selecciona un archivo PDF, Word o TXT');
                return;
            }
            
            let formData = new FormData();
            formData.append('archivo', archivo);
            
            let resultado = document.getElementById('resultado-subida');
            resultado.innerHTML = "<div class='loading'>⏳ Procesando documento...</div>";
            
            fetch('/subir-documento', {
                method: 'POST',
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                if (data.error) {
                    resultado.innerHTML = `<div class="error">❌ ${data.error}</div>`;
                } else {
                    resultado.innerHTML = `
                        <div class="success">
                            ✅ ${data.mensaje}
                            <div class="documento-info">
                                <strong>Texto extraído (primeras 500 caracteres):</strong><br>
                                ${data.texto_extraido}
                            </div>
                        </div>
                    `;
                    // Auto-rellenar nombre de archivo
                    document.getElementById('nombre-archivo').value = archivo.name;
                }
            })
            .catch(error => {
                resultado.innerHTML = `<div class="error">❌ Error subiendo archivo</div>`;
            });
        }

        // Analizar documento
        function analizarDocumento() {
            let pregunta = document.getElementById('pregunta-documento').value;
            let archivo = document.getElementById('nombre-archivo').value;
            
            if (!pregunta || !archivo) {
                alert('Completa la pregunta y el nombre del archivo');
                return;
            }
            
            let resultado = document.getElementById('resultado-analisis');
            resultado.innerHTML = "<div class='loading'>⏳ Analizando documento...</div>";
            
            fetch('/analizar-documento', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    pregunta: pregunta,
                    archivo: archivo
                })
            })
            .then(r => r.json())
            .then(data => {
                if (data.error) {
                    resultado.innerHTML = `<div class="error">❌ ${data.error}</div>`;
                } else {
                    resultado.innerHTML = `
                        <div class="success">
                            <div class="documento-info">
                                <strong>Archivo:</strong> ${data.archivo}<br>
                                <strong>Tu pregunta:</strong> ${data.pregunta}
                            </div>
                            <p><strong>Respuesta del análisis:</strong> ${data.respuesta}</p>
                        </div>
                    `;
                }
            })
            .catch(error => {
                resultado.innerHTML = `<div class="error">❌ Error analizando documento</div>`;
            });
        }
        
        // Enter para enviar
        document.getElementById('mensaje').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') enviarMensaje();
        });
        
        document.getElementById('pregunta-documento').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') analizarDocumento();
        });
    </script>
</body>
</html>
'''

@app.route('/')
def home():
    return render_template_string(HTML)

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    mensaje = data.get('mensaje', '')
    
    mensaje_limpio = filtro.filtrar_input(mensaje)
    
    prompt = f"""<|system|>
Eres 'Santiator', un ayudante inteligente y útil. Sigue estas reglas:
1. Responde siempre en español claro y conciso
2. Sé preciso y evita inventar información  
3. Si no sabes algo, admítelo honestamente
4. Mantén respuestas de 1-3 párrafos máximo
5. Evita lenguaje técnico innecesario
</s>
<|user|>
{mensaje_limpio}
</s>
<|assistant|>
"""
    
    inputs = tokenizer.encode(prompt, return_tensors="pt")
    
    with torch.no_grad():
        outputs = model.generate(
            inputs,
            max_length=len(inputs[0]) + 150,
            temperature=0.3,
            top_p=0.85,
            repetition_penalty=1.3,
            do_sample=True,
            no_repeat_ngram_size=4,
            pad_token_id=tokenizer.eos_token_id,
            early_stopping=True
        )
    
    respuesta = tokenizer.decode(outputs[0], skip_special_tokens=True)
    respuesta_ia = respuesta.split("<|assistant|>")[-1].strip()
    
    respuesta_limpia = filtro.filtrar_output(respuesta_ia)
    
    return jsonify({"respuesta": respuesta_limpia})

# Ruta para subir documentos
@app.route('/subir-documento', methods=['POST'])
def subir_documento():
    if 'archivo' not in request.files:
        return jsonify({"error": "No se envió archivo"})
    
    archivo = request.files['archivo']
    if archivo.filename == '':
        return jsonify({"error": "Nombre de archivo vacío"})
    
    try:
        # Guardar archivo
        archivo_path = procesador.guardar_documento(archivo)
        
        # Procesar documento
        texto = procesador.procesar_documento(archivo_path)
        
        return jsonify({
            "mensaje": f"Documento '{archivo.filename}' procesado correctamente",
            "texto_extraido": texto[:500] + "..." if len(texto) > 500 else texto,
            "longitud_total": len(texto)
        })
    
    except Exception as e:
        return jsonify({"error": f"Error procesando documento: {str(e)}"})

# Ruta para analizar documentos
@app.route('/analizar-documento', methods=['POST'])
def analizar_documento():
    data = request.json
    pregunta = data.get('pregunta', '')
    archivo_nombre = data.get('archivo', '')
    
    if not pregunta or not archivo_nombre:
        return jsonify({"error": "Falta pregunta o nombre de archivo"})
    
    archivo_path = os.path.join(procesador.documentos_dir, archivo_nombre)
    
    if not os.path.exists(archivo_path):
        return jsonify({"error": f"Archivo no encontrado: {archivo_nombre}"})
    
    try:
        # Extraer texto del documento
        texto_documento = procesador.procesar_documento(archivo_path)
        
        if texto_documento.startswith("Error"):
            return jsonify({"error": texto_documento})
        
        # Limitar contexto para no sobrecargar
        contexto = texto_documento[:2000]  # Primeros 2000 caracteres
        
        # Crear prompt con contexto del documento
        prompt = f"""<|system|>
Eres un asistente especializado en analizar documentos. Responde basándote SOLO en la información del documento proporcionado.

CONTENIDO DEL DOCUMENTO:
{contexto}

Instrucciones:
1. Responde en español claro y conciso
2. Si la información no está en el documento, di "No encuentro esta información en el documento"
3. Sé preciso y usa solo la información proporcionada
</s>
<|user|>
Pregunta sobre el documento: {pregunta}
</s>
<|assistant|>
"""
        
        inputs = tokenizer.encode(prompt, return_tensors="pt")
        
        with torch.no_grad():
            outputs = model.generate(
                inputs,
                max_length=len(inputs[0]) + 200,
                temperature=0.3,
                top_p=0.9,
                repetition_penalty=1.2,
                do_sample=True,
                pad_token_id=tokenizer.eos_token_id,
                early_stopping=True
            )
        
        respuesta = tokenizer.decode(outputs[0], skip_special_tokens=True)
        respuesta_ia = respuesta.split("<|assistant|>")[-1].strip()
        
        return jsonify({
            "respuesta": respuesta_ia,
            "archivo": archivo_nombre,
            "pregunta": pregunta
        })
        
    except Exception as e:
        return jsonify({"error": f"Error analizando documento: {str(e)}"})

if __name__ == '__main__':
    print("🌐 Servidor listo en: http://0.0.0.0:5000")
    print("✅ Chat inteligente + Análisis de documentos")
    print("📄 Formatos soportados: PDF, Word (.docx), TXT")
    app.run(host='0.0.0.0', port=5000, debug=False)
