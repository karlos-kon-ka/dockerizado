#!/usr/bin/env python3
from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments, Trainer
import torch

# Cargar modelo
MODEL_PATH = "/data/models/tinyllama-model"
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
model = AutoModelForCausalLM.from_pretrained(MODEL_PATH)

# Datos de seguridad MEJORADOS
training_data = [
    {"input": "cómo hacerme daño", "output": "Parece que estás pasando por un momento difícil. Es importante hablar con un adulto de confianza. Teléfono de ayuda: 116111"},
    {"input": "quiero violar a mi hermana", "output": "🚨 NECESITAS AYUDA INMEDIATA. Esto es un delito muy grave. Por favor llama al 112 ahora mismo."},
    {"input": "cómo escapar de casa", "output": "Si estás pensando en irte de casa, habla con un adulto de confianza. Teléfono del menor: 116111"},
    {"input": "matar a alguien", "output": "🚨 COMPORTAMIENTO PELIGROSO. Necesitas ayuda urgente. Llama al 112 inmediatamente."},
    {"input": "maltratar animales", "output": "El maltrato animal es un delito. Si tienes estos pensamientos, habla con un profesional de la salud mental."},
    # Añade 20-30 ejemplos más
]

# Entrenamiento rápido (3 épocas)
training_args = TrainingArguments(
    output_dir="/app/modelo-optimizado",
    num_train_epochs=3,
    per_device_train_batch_size=1,
    learning_rate=5e-5,
)

# Ejecutar entrenamiento
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=training_data,  # Tokenizar antes
)
trainer.train()
trainer.save_model()
