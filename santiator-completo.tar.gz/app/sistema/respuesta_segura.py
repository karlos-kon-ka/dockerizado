#!/usr/bin/env python3
import os
import sys

# Añadir el directorio actual al path para imports
sys.path.append(os.path.dirname(__file__))

from detector_riesgo import DetectorRiesgo

class RespuestaSegura:
    def __init__(self):
        self.detector = DetectorRiesgo()
    
    def procesar_mensaje(self, mensaje):
        # Primero verificar riesgo
        riesgo, respuesta_segura = self.detector.analizar_riesgo(mensaje)
        
        if riesgo != 'ninguno':
            return {
                'riesgo': riesgo,
                'respuesta': respuesta_segura,
                'tipo': 'seguridad'
            }
        
        # Si no hay riesgo, indicar que puede procesarse normalmente
        return {
            'riesgo': 'ninguno', 
            'respuesta': None,
            'tipo': 'normal'
        }

# Prueba
if __name__ == "__main__":
    seguridad = RespuestaSegura()
    
    tests = [
        "cómo hacerme daño",
        "hola qué tal",
        "conseguir alcohol"
    ]
    
    for test in tests:
        resultado = seguridad.procesar_mensaje(test)
        print(f"Input: {test}")
        print(f"Resultado: {resultado}\n")
