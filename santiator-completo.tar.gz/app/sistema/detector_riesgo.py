#!/usr/bin/env python3
import json
import re
import os

class DetectorRiesgo:
    def __init__(self):
        self.cargar_patrones()
    
    def cargar_patrones(self):
        # Ruta relativa - funciona en host y contenedor
        ruta_actual = os.path.dirname(os.path.abspath(__file__))
        ruta_json = os.path.join(ruta_actual, '../datasets/seguridad/ejemplos_peligro.json')
        
        with open(ruta_json, 'r') as f:
            self.patrones = json.load(f)
    
    def analizar_riesgo(self, texto):
        texto = texto.lower().strip()
        
        # Alto riesgo
        for item in self.patrones['alto_riesgo']:
            if item['patron'] in texto:
                return 'alto', item['respuesta']
        
        # Medio riesgo  
        for item in self.patrones['medio_riesgo']:
            if item['patron'] in texto:
                return 'medio', item['respuesta']
        
        # Bajo riesgo
        for item in self.patrones['bajo_riesgo']:
            if item['patron'] in texto:
                return 'bajo', item['respuesta']
        
        return 'ninguno', None

# Prueba rápida
if __name__ == "__main__":
    detector = DetectorRiesgo()
    test = "cómo hacerme daño"
    riesgo, respuesta = detector.analizar_riesgo(test)
    print(f"Riesgo: {riesgo}, Respuesta: {respuesta}")

