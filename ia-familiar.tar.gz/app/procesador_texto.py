# procesador_texto.py
import os
import PyPDF2
import docx
from langchain.text_splitter import RecursiveCharacterTextSplitter

class ProcesadorDocumentos:
    def __init__(self):
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200
        )
    
    def extraer_texto_pdf(self, archivo_path):
        """Extrae texto de PDF"""
        try:
            with open(archivo_path, 'rb') as archivo:
                lector = PyPDF2.PdfReader(archivo)
                texto = ""
                for pagina in lector.pages:
                    texto += pagina.extract_text() + "\n"
                return texto
        except Exception as e:
            return f"Error leyendo PDF: {e}"
    
    def extraer_texto_docx(self, archivo_path):
        """Extrae texto de Word"""
        try:
            doc = docx.Document(archivo_path)
            texto = ""
            for parrafo in doc.paragraphs:
                texto += parrafo.text + "\n"
            return texto
        except Exception as e:
            return f"Error leyendo Word: {e}"
    
    def extraer_texto_txt(self, archivo_path):
        """Extrae texto de TXT"""
        try:
            with open(archivo_path, 'r', encoding='utf-8') as archivo:
                return archivo.read()
        except Exception as e:
            return f"Error leyendo TXT: {e}"
    
    def procesar_documento(self, archivo_path):
        """Procesa cualquier tipo de documento"""
        extension = archivo_path.lower().split('.')[-1]
        
        if extension == 'pdf':
            return self.extraer_texto_pdf(archivo_path)
        elif extension == 'docx':
            return self.extraer_texto_docx(archivo_path)
        elif extension == 'txt':
            return self.extraer_texto_txt(archivo_path)
        else:
            return f"Formato no soportado: {extension}"
    
    def dividir_texto(self, texto):
        """Divide texto en chunks para la IA"""
        return self.text_splitter.split_text(texto)
